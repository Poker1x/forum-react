import React from 'react';

function Error(props) {
    return (
        <div>
            Page Not found
        </div>
    );
}

export default Error;