import React from 'react';

function Footer(props) {
    return (
        <div class='bg-white border-t-2 p-10 text-center font-bold'>
            Design By Poker
        </div>
    );
}

export default Footer;