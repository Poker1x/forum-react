class Category {
    constructor(){
        this.list = {
            'ban-quan-tri': 'Ban Quản Trị',
            'lap-trinh': 'Lập Trình',
            'linh-tinh': 'Linh Tinh' 
        }
    }
}

export default new Category